# F10-O evidence package
Scientific outcome: F10O_TERMINAL_TRANSFER_FAIL. No product integration.

Original run: Python 3.11, NumPy 2.4.6, torch 2.15.0+cpu, one CPU thread.
The dependency source in frozen/observatory is from commit f1ba7db6364cb92f0443d63a4d13eb527049f60d.
The F10-L checkpoints under original/ are the original GitHub run 41685499939 artifacts.
No credentials or user data are included.

From the extracted package root, with Python dependencies installed:

    python product/observatory/f10o_audit.py --root results
    python product/observatory/f10o_replay.py --frozen frozen --original original --root results

Optional numerical reproduction (NOT a fresh scientific confirmation):

    python product/observatory/f10o_terminal.py --frozen frozen --original original --out reproduction
    python product/observatory/f10o_audit.py --root reproduction

Never overwrite results/. The runner refuses existing replica directories.
Checkpoint file bytes can vary across platforms; compare predictions and numerical weights as appropriate.
SHA256SUMS.json lists exact packaged file hashes, including sealed training source/protocol bytes.
The auxiliary replay had a post-run JSON tuple/list comparison normalization; no training code or outcomes changed.
